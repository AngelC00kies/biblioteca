<?php
const base_url = "http://localhost/biblioteca/";
const host = "localhost";
const user = "root";
const pass = "";
const db = "biblioteca";
const charset = "charset=utf8";
?>